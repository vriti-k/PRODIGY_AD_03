# PRODIGY_AD_03
 Stopwatch app using Kotlin
# StopWatchAppScreenshot
![Screenshot_StopWatch](https://github.com/ankita000z/PRODIGY_AD_03/assets/154900926/ca24bb19-9691-42d3-b9c2-16c280d01d02)
