package com.example.stopwatch

import android.app.Application

class StopWatchApplication: Application() {

    val stopWatchViewModel = StopWatchViewModel()

}